aws_region         = "us-east-1"
cluster_name       = "currency-system-cluster"
kubernetes_version = "1.31"

vpc_cidr           = "10.0.0.0/16"
allowed_cidr       = "0.0.0.0/0"

node_instance_type = "t3.medium"
desired_nodes      = 1
min_nodes          = 1
max_nodes          = 2